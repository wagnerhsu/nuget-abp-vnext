﻿using System;
using Volo.Abp.Data;
using Volo.Abp.Modularity;

namespace Volo.Abp.FeatureManagement.MongoDB;

[DependsOn(
    typeof(FeatureManagementTestBaseModule),
    typeof(AbpFeatureManagementMongoDbModule)
    )]
public class AbpFeatureManagementMongoDbTestModule : AbpModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<AbpDbConnectionOptions>(options =>
        {
            options.ConnectionStrings.Default = MongoDbFixture.GetRandomConnectionString();
        });

    }
}
